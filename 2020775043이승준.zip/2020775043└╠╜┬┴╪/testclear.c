#include<stdio.h>

int main(){
	printf("\033[2J");
	return 0;
}
